#include <iostream>
using namespace std;
int main() {
    int number;
    int count = 0;

    cout << "input :";
    cin >> number;

    for (int i = 1; i <= number ; i++) {
        if (number%i == 0)
            count++;
    }

    if (count == 2)
        cout << number << " Prime";
    else cout << number << " Not prime";




    return 0;
}
